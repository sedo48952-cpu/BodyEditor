@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title BodyEditor Forge 1.21.1 build

echo ============================================
echo BodyEditor - Minecraft Forge 1.21.1
echo Forge 52.1.16
echo Project folder: %CD%
echo ============================================

if not exist "settings.gradle" (
  echo ERROR: settings.gradle was not found.
  echo Extract the ZIP and run this file from the bodyeditor folder.
  pause
  exit /b 1
)

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found in PATH. Install JDK 21.
  pause
  exit /b 1
)

java -version

set "GRADLE_VERSION=8.8"
set "TOOLS_DIR=%LOCALAPPDATA%\BodyEditorBuildTools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"

where gradle >nul 2>nul
if not errorlevel 1 (
  set "GRADLE_CMD=gradle"
  goto build
)

if exist "%GRADLE_EXE%" (
  set "GRADLE_CMD=%GRADLE_EXE%"
  goto build
)

echo Gradle was not found. Downloading Gradle %GRADLE_VERSION%...
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
set "ZIP_FILE=%TOOLS_DIR%\gradle-%GRADLE_VERSION%-bin.zip"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%' } catch { Write-Host $_; exit 1 }"
if errorlevel 1 (
  echo ERROR: Gradle download failed. Check your internet connection.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%TOOLS_DIR%' -Force"
if errorlevel 1 (
  echo ERROR: Could not extract Gradle.
  pause
  exit /b 1
)

set "GRADLE_CMD=%GRADLE_EXE%"

:build
echo.
echo Running Gradle...
call "%GRADLE_CMD%" --stop
if errorlevel 1 echo WARNING: Gradle --stop returned a non-zero code; continuing.
call "%GRADLE_CMD%" --no-daemon --refresh-dependencies clean build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the complete error text above.
  pause
  exit /b 1
)

echo.
echo BUILD COMPLETED. Check the build\libs folder for the JAR.
pause
endlocal
