# BodyEditor — online build with GitHub Actions

This project is configured to build in GitHub's hosted Linux runner with Java 21 and Gradle 8.8.

## How to run the online build

1. Create a repository on https://github.com/new .
2. Upload the *contents* of this `bodyeditor` folder to the repository root (including `.github`).
3. Open the repository's **Actions** tab.
4. Select **Build BodyEditor mod** and click **Run workflow**, or push/commit a change to `main`/`master`.
5. Open the finished run. If successful, download `bodyeditor-jar` from **Artifacts**.
6. If it fails, open the `Compile and build Forge mod` step and copy the error log.

The workflow does not hide or auto-fix Java compiler errors: it runs the real Gradle build and reports the result.
Do not upload secrets or personal access tokens into the source repository.
