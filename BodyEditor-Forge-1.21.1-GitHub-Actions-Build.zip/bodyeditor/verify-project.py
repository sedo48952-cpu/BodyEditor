#!/usr/bin/env python3
"""Offline structural checks for the Body Editor source package (not a Java/Forge build)."""
from pathlib import Path
import json, re, sys
root = Path(__file__).resolve().parent
errors = []
required = [
    root/'build.gradle', root/'settings.gradle',
    root/'src/main/resources/META-INF/mods.toml',
    root/'src/main/java/com/s_core/bodyeditor/BodyEditor.java',
    root/'src/main/java/com/s_core/bodyeditor/command/BodyEditorCommand.java',
    root/'src/main/java/com/s_core/bodyeditor/network/Network.java',
    root/'src/main/java/com/s_core/bodyeditor/client/screen/BodyEditorScreen.java',
]
for path in required:
    if not path.is_file(): errors.append(f'Missing required file: {path.relative_to(root)}')
for path in (root/'src/main/resources/assets/bodyeditor/lang').glob('*.json'):
    try: json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'Invalid JSON {path.name}: {exc}')
command = (root/'src/main/java/com/s_core/bodyeditor/command/BodyEditorCommand.java').read_text()
if '@SubscribeEvent' not in command or 'RegisterCommandsEvent event' not in command:
    errors.append('Command registration event subscription missing')
network = (root/'src/main/java/com/s_core/bodyeditor/network/Network.java').read_text()
if 'recipient.server.getPlayerList().getPlayers()' not in network:
    errors.append('Join synchronization of online player profiles missing')
profile = (root/'src/main/java/com/s_core/bodyeditor/data/BodyProfile.java').read_text()
if 'p.height=read(t,"height")' not in profile:
    errors.append('Backward-compatible defaults for saved profile fields missing')
if errors:
    print('STRUCTURAL CHECKS FAILED')
    print('\n'.join('- '+e for e in errors))
    sys.exit(1)
print(f'PASS: {len(required)} required project files present')
print(f'PASS: {len(list((root/"src/main/resources/assets/bodyeditor/lang").glob("*.json")))} language JSON files parse')
print('PASS: command event subscription, join synchronization, and profile fallback checks')
print('NOTE: This is not a Gradle compilation or an in-game Forge test.')
