package com.s_core.bodyeditor.client.screen;

import com.s_core.bodyeditor.data.BodyProfile;
import com.s_core.bodyeditor.data.ProfileStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** Categorized character editor. Values are server-authoritative and applied live. */
public class BodyEditorScreen extends Screen {
    private static final String[][] KEYS = {
        {"height","width","scale","head","neck"},
        {"torso","shoulders","chest","waist","abdomen","hips","butt"},
        {"arms","forearms","legs","upperlegs","lowerlegs","calves","feet"}
    };
    private static final String[][] LABELS = {
        {"Рост","Ширина тела","Общий масштаб","Размер головы","Шея"},
        {"Длина торса","Плечи","Грудь","Талия","Живот","Бёдра","Ягодицы"},
        {"Руки","Предплечья","Длина ног","Бёдра ног","Голени","Икры","Ступни"}
    };
    private static final String[] TABS = {"Общее","Торс и корпус","Руки и ноги"};
    private final List<Slider> sliders = new ArrayList<>();
    private int tab = 0;

    public BodyEditorScreen() { super(Component.literal("Body Editor — редактор персонажа")); }

    @Override protected void init() {
        clearWidgets(); sliders.clear();
        int center = width / 2;
        int panelLeft = Math.max(12, center - 250);
        addRenderableWidget(Button.builder(Component.literal("Пол: " + genderLabel(local().gender)), b -> {
            BodyProfile.Gender next = switch (local().gender) { case MALE -> BodyProfile.Gender.FEMALE; case FEMALE -> BodyProfile.Gender.NEUTRAL; case NEUTRAL -> BodyProfile.Gender.MALE; };
            send("/bodyeditor gender " + next.name().toLowerCase());
            if (Minecraft.getInstance().player != null) { BodyProfile p=local(); p.defaultsFor(next); ProfileStore.save(Minecraft.getInstance().player,p); }
            reloadEditor();
        }).bounds(panelLeft, 34, 260, 22).build());
        for (int i=0;i<TABS.length;i++) {
            final int selected=i;
            addRenderableWidget(Button.builder(Component.literal((tab==i?"◆ ":"")+TABS[i]), b -> { tab=selected; reloadEditor(); })
                .bounds(panelLeft + i*88, 62, 84, 22).build());
        }
        BodyProfile profile=local();
        for (int i=0;i<KEYS[tab].length;i++) {
            int x=panelLeft, y=96+i*29;
            Slider slider=new Slider(x,y,260,20,Component.literal(LABELS[tab][i]),get(profile,KEYS[tab][i]),KEYS[tab][i]);
            sliders.add(slider); addRenderableWidget(slider);
        }
        int rightX = Math.min(width-190, center+70);
        for (int i=0;i<3;i++) {
            final int slot=i+1;
            addRenderableWidget(Button.builder(Component.literal("Сохранить профиль "+slot), b -> {
                PresetStore.save(slot, local());
            }).bounds(rightX, height-112+i*25, 170, 20).build());
        }
        for (int i=0;i<3;i++) {
            final int slot=i+1;
            addRenderableWidget(Button.builder(Component.literal("Загрузить профиль "+slot), b -> {
                BodyProfile saved=PresetStore.load(slot);
                if(saved!=null) applyProfile(saved);
            }).bounds(rightX+176, height-112+i*25, 170, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Сбросить вкладку"), b -> {
            for(String key:KEYS[tab]) send("/bodyeditor set "+key+" 1.0");
            reloadEditor();
        }).bounds(panelLeft, height-34, 130, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Сбросить всё"), b -> { send("/bodyeditor reset"); reloadEditor(); })
            .bounds(panelLeft+136,height-34,110,22).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose()).bounds(panelLeft+252,height-34,70,22).build());
    }
    private void reloadEditor(){ clearWidgets(); init(); }
    private void applyProfile(BodyProfile p) {
        send("/bodyeditor gender " + p.gender.name().toLowerCase(java.util.Locale.ROOT));
        for (String[] group : KEYS) for (String key : group)
            send("/bodyeditor set " + key + " " + String.format(java.util.Locale.ROOT, "%.3f", get(p,key)));
        reloadEditor();
    }
    private BodyProfile local(){ if(Minecraft.getInstance().player==null)return new BodyProfile(); return ProfileStore.get(Minecraft.getInstance().player); }
    private static String genderLabel(BodyProfile.Gender g){ return switch(g){case MALE->"Мужской";case FEMALE->"Женский";case NEUTRAL->"Нейтральный";}; }
    private static float get(BodyProfile p,String k){ return switch(k){
        case "height"->p.height; case "width"->p.width; case "head"->p.head; case "torso"->p.torso; case "shoulders"->p.shoulders; case "chest"->p.chest; case "waist"->p.waist; case "hips"->p.hips; case "arms"->p.arms; case "legs"->p.legs; case "scale"->p.scale; case "abdomen"->p.abdomen; case "butt"->p.butt; case "neck"->p.neck; case "upperlegs"->p.upperLegs; case "lowerlegs"->p.lowerLegs; case "forearms"->p.forearms; case "calves"->p.calves; case "feet"->p.feet; default->1.0f; }; }
    private static void send(String command){ if(Minecraft.getInstance().player!=null) Minecraft.getInstance().player.connection.sendCommand(command.replaceFirst("^/", "")); }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float pt){
        renderBackground(g,mouseX,mouseY,pt);
        g.drawCenteredString(font,title,width/2,12,0xFFFFFF);
        g.drawCenteredString(font,"Настройка 70–135% · изменения применяются сразу",width/2,height-126,0xA0D8FF);
        Minecraft mc=Minecraft.getInstance();
        if (mc.player != null) {
            int x1=Math.min(width-190,width/2+65), x2=Math.min(width-12,x1+170);
            int y2=Math.max(160,height-135), y1=Math.max(70,y2-210);
            g.drawCenteredString(font,"Предпросмотр 3D",(x1+x2)/2,y1-14,0xFFFFFF);
            InventoryScreen.renderEntityInInventoryFollowsMouse(g,x1,y1,x2,y2,72,0.0F,mouseX,mouseY,mc.player);
        }
        super.render(g,mouseX,mouseY,pt);
    }
    private static class Slider extends AbstractSliderButton {
        private final String key; private final Component label;
        Slider(int x,int y,int w,int h,Component label,float value,String key){super(x,y,w,h,label,(value-0.70)/0.65);this.key=key;this.label=label;updateMessage();}
        protected void updateMessage(){setMessage(Component.literal(label.getString()+": "+Math.round((0.70+value*0.65)*100)+"%"));}
        protected void applyValue(){send("/bodyeditor set "+key+" "+String.format(java.util.Locale.ROOT,"%.3f",0.70+value*0.65));}
    }
}
