package com.s_core.bodyeditor.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public final class ProfileStore {
    private static final String KEY = "bodyeditor_profile";
    private ProfileStore() {}
    public static BodyProfile get(Player player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(KEY)) {
            BodyProfile p = new BodyProfile(); p.defaultsFor(BodyProfile.Gender.NEUTRAL); save(player,p); return p;
        }
        return BodyProfile.load(root.getCompound(KEY));
    }
    public static void save(Player player, BodyProfile profile) { profile.clamp(); player.getPersistentData().put(KEY, profile.save()); }
}
