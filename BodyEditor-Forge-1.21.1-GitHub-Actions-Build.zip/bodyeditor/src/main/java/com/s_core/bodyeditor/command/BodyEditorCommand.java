package com.s_core.bodyeditor.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.CommandDispatcher;
import com.s_core.bodyeditor.data.BodyProfile;
import com.s_core.bodyeditor.data.ProfileStore;
import com.s_core.bodyeditor.network.Network;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class BodyEditorCommand {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) { register(event.getDispatcher()); }
    private static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("bodyeditor")
            .then(Commands.literal("gender").then(Commands.argument("value", StringArgumentType.word()).executes(c -> setGender(c.getSource().getPlayerOrException(), StringArgumentType.getString(c,"value")))))
            .then(Commands.literal("set").then(Commands.argument("part", StringArgumentType.word()).then(Commands.argument("value", FloatArgumentType.floatArg(0.7f,1.35f)).executes(c -> setPart(c.getSource().getPlayerOrException(), StringArgumentType.getString(c,"part"), FloatArgumentType.getFloat(c,"value"))))))
            .then(Commands.literal("reset").executes(c -> reset(c.getSource().getPlayerOrException()))));
    }
    private static int setGender(ServerPlayer p,String s) {
        BodyProfile.Gender g = switch(s.toLowerCase()) { case "male","m" -> BodyProfile.Gender.MALE; case "female","f" -> BodyProfile.Gender.FEMALE; default -> BodyProfile.Gender.NEUTRAL; };
        BodyProfile b=ProfileStore.get(p); b.defaultsFor(g); ProfileStore.save(p,b); Network.sync(p); return 1;
    }
    private static int setPart(ServerPlayer p,String part,float v) {
        BodyProfile b=ProfileStore.get(p);
        switch(part.toLowerCase()) { case "height"->b.height=v; case "width"->b.width=v; case "head"->b.head=v; case "torso"->b.torso=v; case "shoulders"->b.shoulders=v; case "chest"->b.chest=v; case "waist"->b.waist=v; case "hips"->b.hips=v; case "arms"->b.arms=v; case "legs"->b.legs=v; case "scale"->b.scale=v; case "abdomen"->b.abdomen=v; case "butt"->b.butt=v; case "neck"->b.neck=v; case "upperlegs"->b.upperLegs=v; case "lowerlegs"->b.lowerLegs=v; case "forearms"->b.forearms=v; case "calves"->b.calves=v; case "feet"->b.feet=v; default->{} }
        ProfileStore.save(p,b); Network.sync(p); return 1;
    }
    private static int reset(ServerPlayer p) { BodyProfile b=ProfileStore.get(p); b.defaultsFor(b.gender); ProfileStore.save(p,b); Network.sync(p); return 1; }
}
