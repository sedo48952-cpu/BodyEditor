package com.s_core.bodyeditor.client.screen;

import com.s_core.bodyeditor.data.BodyProfile;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.client.Minecraft;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Stores three client-side profile snapshots in the Minecraft config directory. */
final class PresetStore {
    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("bodyeditor-presets.properties");
    }
    private static Properties read() {
        Properties p = new Properties();
        try { Path f=file(); if(Files.exists(f)) try(var in=Files.newInputStream(f)){ p.load(in); } }
        catch(IOException ignored) { }
        return p;
    }
    static void save(int slot, BodyProfile profile) {
        try {
            Path f=file(); Files.createDirectories(f.getParent());
            Properties p=read(); p.setProperty("profile."+slot, profile.save().toString());
            try(var out=Files.newOutputStream(f)){ p.store(out,"Body Editor Advanced presets"); }
        } catch(IOException ignored) { }
    }
    static BodyProfile load(int slot) {
        String raw=read().getProperty("profile."+slot);
        if(raw==null || raw.isBlank()) return null;
        try { return BodyProfile.load(TagParser.parseTag(raw)); }
        catch(Exception ignored) { return null; }
    }
    private PresetStore() { }
}
