package com.s_core.bodyeditor.client;

import com.s_core.bodyeditor.client.screen.BodyEditorScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.glfw.GLFW;

public final class ClientInit {
    private static final KeyMapping OPEN = new KeyMapping("key.bodyeditor.open", GLFW.GLFW_KEY_B, "key.categories.bodyeditor");
    public static void init() {
        net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus().addListener(ClientInit::registerKeys);
        MinecraftForge.EVENT_BUS.register(new ClientInit());
        MinecraftForge.EVENT_BUS.register(new BodyRenderHandler());
    }
    private static void registerKeys(RegisterKeyMappingsEvent e) { e.register(OPEN); }
    @net.minecraftforge.eventbus.api.SubscribeEvent public void input(InputEvent.Key e) {
        if (OPEN.consumeClick() && Minecraft.getInstance().screen == null) Minecraft.getInstance().setScreen(new BodyEditorScreen());
    }
}
