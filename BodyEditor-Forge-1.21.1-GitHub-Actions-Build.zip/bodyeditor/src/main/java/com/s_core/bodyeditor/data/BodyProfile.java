package com.s_core.bodyeditor.data;

import net.minecraft.nbt.CompoundTag;

public class BodyProfile {
    public enum Gender { MALE, FEMALE, NEUTRAL }

    public Gender gender = Gender.NEUTRAL;
    public float height = 1.0f;
    public float width = 1.0f;
    public float head = 1.0f;
    public float torso = 1.0f;
    public float shoulders = 1.0f;
    public float chest = 1.0f;
    public float waist = 1.0f;
    public float hips = 1.0f;
    public float arms = 1.0f;
    public float legs = 1.0f;
    public float scale = 1.0f;
    public float abdomen = 1.0f;
    public float butt = 1.0f;
    public float neck = 1.0f;
    public float upperLegs = 1.0f;
    public float lowerLegs = 1.0f;
    public float forearms = 1.0f;
    public float calves = 1.0f;
    public float feet = 1.0f;

    public BodyProfile copy() {
        BodyProfile p = new BodyProfile();
        p.gender = gender; p.height=height; p.width=width; p.head=head; p.torso=torso;
        p.shoulders=shoulders; p.chest=chest; p.waist=waist; p.hips=hips; p.arms=arms; p.legs=legs; p.scale=scale;
        p.abdomen=abdomen; p.butt=butt; p.neck=neck; p.upperLegs=upperLegs; p.lowerLegs=lowerLegs; p.forearms=forearms; p.calves=calves; p.feet=feet;
        return p;
    }

    public void defaultsFor(Gender g) {
        gender = g;
        height = g == Gender.FEMALE ? 0.98f : g == Gender.MALE ? 1.02f : 1.0f;
        width = g == Gender.FEMALE ? 0.98f : g == Gender.MALE ? 1.02f : 1.0f;
        head = 1.0f; torso=1.0f;
        shoulders = g == Gender.FEMALE ? 0.92f : g == Gender.MALE ? 1.08f : 1.0f;
        chest = g == Gender.FEMALE ? 1.10f : 0.80f;
        waist = g == Gender.FEMALE ? 0.92f : 1.0f;
        hips = g == Gender.FEMALE ? 1.08f : g == Gender.MALE ? 0.96f : 1.0f;
        arms=1.0f; legs=1.0f; scale=1.0f; abdomen=1.0f; butt=1.0f; neck=1.0f; upperLegs=1.0f; lowerLegs=1.0f; forearms=1.0f; calves=1.0f; feet=1.0f;
    }

    public void clamp() {
        height=cl(height); width=cl(width); head=cl(head); torso=cl(torso); shoulders=cl(shoulders);
        chest=cl(chest); waist=cl(waist); hips=cl(hips); arms=cl(arms); legs=cl(legs); scale=cl(scale);
        abdomen=cl(abdomen); butt=cl(butt); neck=cl(neck); upperLegs=cl(upperLegs); lowerLegs=cl(lowerLegs); forearms=cl(forearms); calves=cl(calves); feet=cl(feet);
    }
    private static float read(CompoundTag t, String key) { return t.contains(key) ? t.getFloat(key) : 1.0f; }
    private static float cl(float v) { return Math.max(0.70f, Math.min(1.35f, v)); }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("gender", gender.name());
        t.putFloat("height",height); t.putFloat("width",width); t.putFloat("head",head); t.putFloat("torso",torso);
        t.putFloat("shoulders",shoulders); t.putFloat("chest",chest); t.putFloat("waist",waist); t.putFloat("hips",hips);
        t.putFloat("arms",arms); t.putFloat("legs",legs); t.putFloat("scale",scale);
        t.putFloat("abdomen",abdomen); t.putFloat("butt",butt); t.putFloat("neck",neck); t.putFloat("upperLegs",upperLegs); t.putFloat("lowerLegs",lowerLegs); t.putFloat("forearms",forearms); t.putFloat("calves",calves); t.putFloat("feet",feet); return t;
    }
    public static BodyProfile load(CompoundTag t) {
        BodyProfile p = new BodyProfile();
        if (t.contains("gender")) try { p.gender=Gender.valueOf(t.getString("gender")); } catch (Exception ignored) {}
        p.height=read(t,"height"); p.width=read(t,"width"); p.head=read(t,"head"); p.torso=read(t,"torso");
        p.shoulders=read(t,"shoulders"); p.chest=read(t,"chest"); p.waist=read(t,"waist"); p.hips=read(t,"hips");
        p.arms=read(t,"arms"); p.legs=read(t,"legs"); p.scale=read(t,"scale");
        p.abdomen=read(t,"abdomen"); p.butt=read(t,"butt"); p.neck=read(t,"neck"); p.upperLegs=read(t,"upperLegs"); p.lowerLegs=read(t,"lowerLegs"); p.forearms=read(t,"forearms"); p.calves=read(t,"calves"); p.feet=read(t,"feet"); p.clamp(); return p;
    }
}
