package com.s_core.bodyeditor.network;

import com.s_core.bodyeditor.data.BodyProfile;
import com.s_core.bodyeditor.data.ProfileStore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.SimpleChannel;

import java.util.UUID;

public final class Network {
    private static final int PROTOCOL = 1;

    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath("bodyeditor", "main"))
            .networkProtocolVersion(PROTOCOL)
            .acceptedVersions((status, version) -> version == PROTOCOL)
            .simpleChannel();

    private static int id = 0;

    private Network() {}

    public static void init() {
        CHANNEL.messageBuilder(ProfilePacket.class, id++, PacketFlow.CLIENTBOUND)
                .encoder(ProfilePacket::encode)
                .decoder(ProfilePacket::decode)
                .consumerMainThread(ProfilePacket::handle)
                .add();
    }

    public static void sync(ServerPlayer player) {
        BodyProfile profile = ProfileStore.get(player);
        CHANNEL.send(PacketDistributor.ALL.noArg(), new ProfilePacket(player.getUUID(), profile));
    }

    public static void sendTo(ServerPlayer recipient) {
        // Send every currently online player's profile to a newly connected client.
        for (ServerPlayer subject : recipient.server.getPlayerList().getPlayers()) {
            CHANNEL.send(PacketDistributor.PLAYER.with(recipient),
                    new ProfilePacket(subject.getUUID(), ProfileStore.get(subject)));
        }
    }

    public record ProfilePacket(UUID uuid, BodyProfile profile) {
        public ProfilePacket {
            profile = profile.copy();
        }

        public static void encode(ProfilePacket message, FriendlyByteBuf buffer) {
            buffer.writeUUID(message.uuid);
            BodyProfile profile = message.profile;
            buffer.writeEnum(profile.gender);
            buffer.writeFloat(profile.height);
            buffer.writeFloat(profile.width);
            buffer.writeFloat(profile.head);
            buffer.writeFloat(profile.torso);
            buffer.writeFloat(profile.shoulders);
            buffer.writeFloat(profile.chest);
            buffer.writeFloat(profile.waist);
            buffer.writeFloat(profile.hips);
            buffer.writeFloat(profile.arms);
            buffer.writeFloat(profile.legs);
            buffer.writeFloat(profile.scale);
            buffer.writeFloat(profile.abdomen);
            buffer.writeFloat(profile.butt);
            buffer.writeFloat(profile.neck);
            buffer.writeFloat(profile.upperLegs);
            buffer.writeFloat(profile.lowerLegs);
            buffer.writeFloat(profile.forearms);
            buffer.writeFloat(profile.calves);
            buffer.writeFloat(profile.feet);
        }

        public static ProfilePacket decode(FriendlyByteBuf buffer) {
            UUID uuid = buffer.readUUID();
            BodyProfile profile = new BodyProfile();
            profile.gender = buffer.readEnum(BodyProfile.Gender.class);
            profile.height = buffer.readFloat();
            profile.width = buffer.readFloat();
            profile.head = buffer.readFloat();
            profile.torso = buffer.readFloat();
            profile.shoulders = buffer.readFloat();
            profile.chest = buffer.readFloat();
            profile.waist = buffer.readFloat();
            profile.hips = buffer.readFloat();
            profile.arms = buffer.readFloat();
            profile.legs = buffer.readFloat();
            profile.scale = buffer.readFloat();
            profile.abdomen = buffer.readFloat();
            profile.butt = buffer.readFloat();
            profile.neck = buffer.readFloat();
            profile.upperLegs = buffer.readFloat();
            profile.lowerLegs = buffer.readFloat();
            profile.forearms = buffer.readFloat();
            profile.calves = buffer.readFloat();
            profile.feet = buffer.readFloat();
            profile.clamp();
            return new ProfilePacket(uuid, profile);
        }

        public static void handle(ProfilePacket message, CustomPayloadEvent.Context context) {
            // consumerMainThread ensures this executes on the game thread.
            if (!context.isClientSide()) return;
            var minecraft = net.minecraft.client.Minecraft.getInstance();
            com.s_core.bodyeditor.client.ClientProfiles.put(message.uuid, message.profile);
            if (minecraft.player != null && minecraft.player.getUUID().equals(message.uuid)) {
                ProfileStore.save(minecraft.player, message.profile);
            }
            context.setPacketHandled(true);
        }
    }
}
