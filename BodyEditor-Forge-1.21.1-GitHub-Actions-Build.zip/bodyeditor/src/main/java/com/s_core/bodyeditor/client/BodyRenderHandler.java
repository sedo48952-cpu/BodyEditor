package com.s_core.bodyeditor.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.s_core.bodyeditor.data.BodyProfile;
import com.s_core.bodyeditor.render.IndependentBodyMesh;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.IdentityHashMap;
import java.util.Map;

/** Replaces the vanilla torso mesh for rendering while preserving the model's body pose. */
public final class BodyRenderHandler {
    private final Map<PlayerModel<?>, State> originals = new IdentityHashMap<>();

    @SubscribeEvent
    public void pre(RenderPlayerEvent.Pre event) {
        Player player = event.getEntity();
        BodyProfile profile = ClientProfiles.get(player.getUUID());
        if (profile == null) return;

        // Compatibility safety: standard vanilla armor/clothing models have fixed
        // cuboids and cannot yet conform to the independent mesh. Keep the entire
        // vanilla player model whenever any armor slot is occupied, avoiding visible
        // clipping through chestplates, leggings, helmets, or boots.
        if (hasArmorOrEquipment(player)) return;

        PlayerRenderer renderer = event.getRenderer();
        PlayerModel<?> model = renderer.getModel();
        State previous = new State(model);
        originals.put(model, previous);

        // Render the replacement mesh in the exact body-part coordinate frame, so
        // sneaking/torso rotations follow the same animation as the vanilla model.
        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        try {
            model.body.translateAndRotate(poseStack);
            VertexConsumer consumer = event.getMultiBufferSource().getBuffer(
                    RenderType.entityCutoutNoCull(renderer.getTextureLocation((AbstractClientPlayer) player)));
            IndependentBodyMesh.render(poseStack, consumer, event.getPackedLight(), profile);
        } finally {
            poseStack.popPose();
        }

        // Hide only the vanilla skin torso and its outer jacket layer. Separate
        // armor render layers still render afterwards and remain visible.
        model.body.visible = false;
        model.jacket.visible = false;

        set(model.head, profile.head * profile.scale, profile.head * profile.scale, profile.head * profile.scale);
        set(model.leftArm, profile.arms * profile.shoulders * profile.scale,
                profile.arms * profile.forearms * profile.height * profile.scale,
                profile.arms * profile.forearms * profile.scale);
        set(model.rightArm, profile.arms * profile.shoulders * profile.scale,
                profile.arms * profile.forearms * profile.height * profile.scale,
                profile.arms * profile.forearms * profile.scale);
        set(model.leftLeg, profile.hips * profile.upperLegs * profile.legs * profile.scale,
                profile.legs * profile.lowerLegs * profile.height * profile.scale,
                profile.legs * profile.calves * profile.feet * profile.scale);
        set(model.rightLeg, profile.hips * profile.upperLegs * profile.legs * profile.scale,
                profile.legs * profile.lowerLegs * profile.height * profile.scale,
                profile.legs * profile.calves * profile.feet * profile.scale);
    }

    @SubscribeEvent
    public void post(RenderPlayerEvent.Post event) {
        PlayerModel<?> model = event.getRenderer().getModel();
        State state = originals.remove(model);
        if (state != null) state.restore(model);
    }

    private static boolean hasArmorOrEquipment(Player player) {
        return !player.getItemBySlot(EquipmentSlot.HEAD).isEmpty()
                || !player.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
                || !player.getItemBySlot(EquipmentSlot.LEGS).isEmpty()
                || !player.getItemBySlot(EquipmentSlot.FEET).isEmpty();
    }

    private static void set(ModelPart part, float x, float y, float z) {
        part.xScale = x; part.yScale = y; part.zScale = z;
    }

    private static final class State {
        private final float[] scales;
        private final boolean bodyVisible, jacketVisible;
        State(PlayerModel<?> m) {
            scales = new float[] {
                    m.head.xScale,m.head.yScale,m.head.zScale,
                    m.body.xScale,m.body.yScale,m.body.zScale,
                    m.leftArm.xScale,m.leftArm.yScale,m.leftArm.zScale,
                    m.rightArm.xScale,m.rightArm.yScale,m.rightArm.zScale,
                    m.leftLeg.xScale,m.leftLeg.yScale,m.leftLeg.zScale,
                    m.rightLeg.xScale,m.rightLeg.yScale,m.rightLeg.zScale
            };
            bodyVisible = m.body.visible;
            jacketVisible = m.jacket.visible;
        }
        void restore(PlayerModel<?> m) {
            restorePart(m.head,0); restorePart(m.body,3); restorePart(m.leftArm,6);
            restorePart(m.rightArm,9); restorePart(m.leftLeg,12); restorePart(m.rightLeg,15);
            m.body.visible = bodyVisible;
            m.jacket.visible = jacketVisible;
        }
        private void restorePart(ModelPart p, int i) {
            p.xScale=scales[i]; p.yScale=scales[i+1]; p.zScale=scales[i+2];
        }
    }
}
