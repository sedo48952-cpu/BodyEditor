package com.s_core.bodyeditor.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.s_core.bodyeditor.data.BodyProfile;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;

/**
 * Client-side, independently generated torso mesh. Coordinates are in the same
 * 1/16-block model units used by PlayerModel. The torso is built from profile
 * rings rather than scaling the vanilla cuboid; optional chest and glute forms
 * are separate ellipsoidal meshes.
 */
public final class IndependentBodyMesh {
    private static final int RING_SEGMENTS = 24;
    private static final int SPHERE_LAT = 10;
    private static final int SPHERE_LON = 20;

    private IndependentBodyMesh() {}

    public static void render(PoseStack stack, VertexConsumer out, int packedLight, BodyProfile p) {
        float width = p.width * p.shoulders;
        float height = p.height * p.torso;
        // y, half-width, half-depth, front offset, back offset
        float[][] rings = new float[][] {
            {0.0f, 3.45f * width, 1.70f * p.width, 0.00f, 0.00f},
            {1.4f, 3.85f * width, 1.95f * p.chest, 0.10f, 0.00f},
            {3.1f, 3.95f * width * p.chest, 2.00f * p.chest, 0.28f * p.chest, 0.00f},
            {4.5f, 3.45f * width, 1.78f * p.width, 0.05f, 0.00f},
            {6.4f, 2.95f * p.waist * p.width, 1.55f * p.waist, 0.00f, 0.00f},
            {8.1f, 3.20f * p.abdomen * p.width, 1.75f * p.abdomen, 0.00f, 0.00f},
            {9.8f, 3.75f * p.hips * p.width, 1.95f * p.hips, 0.00f, 0.18f * p.butt},
            {11.3f, 3.55f * p.hips * p.width, 1.90f * p.hips, 0.00f, 0.35f * p.butt},
            {12.0f, 3.15f * p.hips * p.width, 1.65f * p.hips, 0.00f, 0.20f * p.butt}
        };
        float[][] verts = new float[rings.length][RING_SEGMENTS * 3];
        for (int r = 0; r < rings.length; r++) {
            float y = rings[r][0] * height;
            float rx = rings[r][1];
            float rz = rings[r][2];
            float front = rings[r][3];
            float back = rings[r][4];
            for (int i = 0; i < RING_SEGMENTS; i++) {
                float a = (float)(Math.PI * 2.0 * i / RING_SEGMENTS);
                float c = Mth.cos(a), s = Mth.sin(a);
                float x = c * rx;
                float z = s * rz;
                if (s < 0) z -= front * -s;
                else z += back * s;
                int k = i * 3;
                verts[r][k] = x; verts[r][k + 1] = y; verts[r][k + 2] = z;
            }
        }
        for (int r = 0; r < rings.length - 1; r++) {
            for (int i = 0; i < RING_SEGMENTS; i++) {
                int j = (i + 1) % RING_SEGMENTS;
                float u0 = 16f / 64f + (8f / 64f) * i / RING_SEGMENTS;
                float u1 = 16f / 64f + (8f / 64f) * (i + 1) / RING_SEGMENTS;
                float v0 = 16f / 64f + (12f / 64f) * rings[r][0] / 12f;
                float v1 = 16f / 64f + (12f / 64f) * rings[r + 1][0] / 12f;
                vertex(stack, out, packedLight, verts[r][i*3], verts[r][i*3+1], verts[r][i*3+2], u0, v0);
                vertex(stack, out, packedLight, verts[r+1][i*3], verts[r+1][i*3+1], verts[r+1][i*3+2], u0, v1);
                vertex(stack, out, packedLight, verts[r+1][j*3], verts[r+1][j*3+1], verts[r+1][j*3+2], u1, v1);
                vertex(stack, out, packedLight, verts[r][i*3], verts[r][i*3+1], verts[r][i*3+2], u0, v0);
                vertex(stack, out, packedLight, verts[r+1][j*3], verts[r+1][j*3+1], verts[r+1][j*3+2], u1, v1);
                vertex(stack, out, packedLight, verts[r][j*3], verts[r][j*3+1], verts[r][j*3+2], u1, v0);
            }
        }

        // Distinct front chest forms. Low chest values flatten these into the torso.
        float chest = Math.max(0.0f, (p.chest - 0.74f) * 2.6f);
        if (chest > 0.02f) {
            ellipsoid(stack, out, packedLight, -1.18f * width, 3.15f * height, -1.72f,
                    0.70f * chest, 0.62f * chest * height, 0.42f * chest, false);
            ellipsoid(stack, out, packedLight,  1.18f * width, 3.15f * height, -1.72f,
                    0.70f * chest, 0.62f * chest * height, 0.42f * chest, false);
        }
        // Separate glute volumes on the rear side of the pelvis.
        float glutes = Math.max(0.0f, p.butt - 0.70f) * 2.2f;
        if (glutes > 0.02f) {
            ellipsoid(stack, out, packedLight, -1.45f * p.hips, 10.25f * height, 2.0f,
                    1.05f * glutes, 1.20f * glutes * height, 0.48f * glutes, true);
            ellipsoid(stack, out, packedLight,  1.45f * p.hips, 10.25f * height, 1.48f,
                    1.05f * glutes, 1.20f * glutes * height, 0.48f * glutes, true);
        }
    }

    private static void ellipsoid(PoseStack stack, VertexConsumer out, int light,
                                  float cx, float cy, float cz, float rx, float ry, float rz, boolean back) {
        for (int lat = 0; lat < SPHERE_LAT; lat++) {
            float p0 = (float)(-Math.PI / 2 + Math.PI * lat / SPHERE_LAT);
            float p1 = (float)(-Math.PI / 2 + Math.PI * (lat + 1) / SPHERE_LAT);
            for (int lon = 0; lon < SPHERE_LON; lon++) {
                float a0 = (float)(Math.PI * 2 * lon / SPHERE_LON);
                float a1 = (float)(Math.PI * 2 * (lon + 1) / SPHERE_LON);
                float[] a = point(cx,cy,cz,rx,ry,rz,p0,a0);
                float[] b = point(cx,cy,cz,rx,ry,rz,p1,a0);
                float[] c = point(cx,cy,cz,rx,ry,rz,p1,a1);
                float[] d = point(cx,cy,cz,rx,ry,rz,p0,a1);
                float u0 = 16f/64f + (8f/64f)*lon/SPHERE_LON;
                float u1 = 16f/64f + (8f/64f)*(lon+1)/SPHERE_LON;
                float v0 = 16f/64f + (12f/64f)*lat/SPHERE_LAT;
                float v1 = 16f/64f + (12f/64f)*(lat+1)/SPHERE_LAT;
                tri(stack,out,light,a,b,c,u0,v0,u0,v1,u1,v1,back);
                tri(stack,out,light,a,c,d,u0,v0,u1,v1,u1,v0,back);
            }
        }
    }

    private static float[] point(float cx,float cy,float cz,float rx,float ry,float rz,float lat,float lon) {
        float cl = Mth.cos(lat);
        return new float[]{cx + rx*cl*Mth.cos(lon), cy + ry*Mth.sin(lat), cz + rz*cl*Mth.sin(lon)};
    }

    private static void tri(PoseStack stack, VertexConsumer out, int light, float[] a,float[] b,float[] c,
                            float ua,float va,float ub,float vb,float uc,float vc,boolean reverse) {
        float ux=b[0]-a[0], uy=b[1]-a[1], uz=b[2]-a[2];
        float vx=c[0]-a[0], vy=c[1]-a[1], vz=c[2]-a[2];
        float nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len>1.0e-6f){nx/=len;ny/=len;nz/=len;}
        if(reverse){nx=-nx;ny=-ny;nz=-nz;}
        emit(stack,out,light,a,ua,va,nx,ny,nz);
        emit(stack,out,light,reverse?c:b,ub,vb,nx,ny,nz);
        emit(stack,out,light,reverse?b:c,uc,vc,nx,ny,nz);
    }

    private static void vertex(PoseStack stack, VertexConsumer out, int light,
                               float x,float y,float z,float u,float v) {
        float nx=x, ny=(y-6f)*0.10f, nz=z;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len>1.0e-6f){nx/=len;ny/=len;nz/=len;}
        PoseStack.Pose pose=stack.last();
        out.addVertex(pose.pose(),x,y,z).setColor(255,255,255,255).setUv(u,v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx,ny,nz);
    }

    private static void emit(PoseStack stack, VertexConsumer out, int light, float[] p,float u,float v,float nx,float ny,float nz) {
        PoseStack.Pose pose=stack.last();
        out.addVertex(pose.pose(),p[0],p[1],p[2]).setColor(255,255,255,255).setUv(u,v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,nx,ny,nz);
    }
}
