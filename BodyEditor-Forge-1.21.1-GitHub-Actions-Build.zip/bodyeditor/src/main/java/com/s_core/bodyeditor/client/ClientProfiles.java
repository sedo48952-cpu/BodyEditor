package com.s_core.bodyeditor.client;

import com.s_core.bodyeditor.data.BodyProfile;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ClientProfiles {
    private static final Map<UUID, BodyProfile> DATA = new ConcurrentHashMap<>();
    public static void put(UUID id, BodyProfile p) { DATA.put(id, p.copy()); }
    public static BodyProfile get(UUID id) { return DATA.get(id); }
    public static void clear() { DATA.clear(); }
}
