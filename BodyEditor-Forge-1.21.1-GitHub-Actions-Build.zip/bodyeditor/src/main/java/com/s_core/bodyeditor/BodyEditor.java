package com.s_core.bodyeditor;

import com.s_core.bodyeditor.client.ClientInit;
import com.s_core.bodyeditor.command.BodyEditorCommand;
import com.s_core.bodyeditor.network.Network;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(BodyEditor.MOD_ID)
public final class BodyEditor {
    public static final String MOD_ID = "bodyeditor";
    public BodyEditor() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Network.init();
        MinecraftForge.EVENT_BUS.register(BodyEditorCommand.class);
        MinecraftForge.EVENT_BUS.register(this);
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientInit::init);
    }
    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            Network.sendTo(p); // Existing profiles to the joining player.
            Network.sync(p);   // Joining player's profile to everyone already online.
        }
    }
    @SubscribeEvent public void respawn(PlayerEvent.PlayerRespawnEvent e) { if(e.getEntity() instanceof ServerPlayer p) Network.sync(p); }
}
