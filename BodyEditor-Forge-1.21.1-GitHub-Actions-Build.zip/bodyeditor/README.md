# Body Editor Advanced — Forge 1.21.1

An open-source **source project** for Minecraft Forge 1.21.1 / Java 21. This package is not a precompiled JAR; build it locally with Gradle before installing it.

## Features

- Visual gender presets: male, female, neutral (appearance profile only; it does not change game mechanics).
- Editor screen on **B** with three categories and 70–135% sliders.
- Parameters: height, width, overall scale, head, neck, torso, shoulders, chest, waist, abdomen, hips, buttocks, arms, forearms, legs, upper legs, lower legs, calves, feet.
- Three local presets in `config/bodyeditor-presets.properties`.
- Player persistent-data storage, server-side commands, and profile packet synchronization.
- A vanilla player-model preview in the editor.
- An independent generated torso mesh: chest/torso cross-section rings, waist and abdomen shaping, hip silhouette, separate front chest volumes and rear glute volumes. The mesh uses the player skin texture and inherits the vanilla body-part pose for basic torso animation.

## Build a real JAR

Requirements: JDK 21 and Gradle 8.x compatible with ForgeGradle 6. The build needs internet access on the first run so Gradle can download ForgeGradle and Minecraft/Forge dependencies.

From this directory run:

```bash
gradle build
```

On Windows, run `gradle.bat build` if you have a Gradle installation. The output should be under `build/libs/`. Install the resulting `bodyeditor-1.0.0.jar` into the `mods` directory of a Forge 1.21.1 client. Install the same mod on the server if using multiplayer.

## Commands

- `/bodyeditor gender male|female|neutral`
- `/bodyeditor set <part> <0.70..1.35>`
- `/bodyeditor reset`

Supported parts: `height`, `width`, `scale`, `head`, `neck`, `torso`, `shoulders`, `chest`, `waist`, `abdomen`, `hips`, `butt`, `arms`, `forearms`, `legs`, `upperlegs`, `lowerlegs`, `calves`, `feet`.

## Important limitations

The torso is now rendered from an independent ring-based mesh instead of scaling the vanilla torso cuboid; chest and glute forms are separate meshes, and the mesh follows the vanilla body-part pose for basic torso animation. Arms, legs, and head still use the standard player model. Armor and clothing layers still use their vanilla geometry: they render over the custom torso, but may clip or float and are not yet reshaped to the body profile. Height/body scaling does not resize the player collision box. The gender option changes the visual profile only. This is a first custom-mesh implementation, not a fully tested production-grade body system; it still needs a successful ForgeGradle build and in-game tests for animation, skins, armor/clothing fit, and multiplayer rendering.

## Verification status

The source package was reviewed for known logic issues and updated so the command registration event is subscribed, joining clients receive profiles for currently online players, and older/incomplete saved profile tags default missing values to 100%. **A Gradle compilation could not be run in the preparation environment** because Gradle is not installed and external downloads are unavailable. Therefore no verified ready-to-install JAR is included. Build and test in a network-enabled ForgeGradle environment before using it in a world/server.


## Stage 2: animation and equipment compatibility
The custom torso mesh is rendered in the vanilla torso pose frame. Vertical scaling of the auxiliary chest and glute volumes is corrected. As a temporary compatibility safeguard, the renderer falls back to the vanilla player model whenever any armor equipment slot is occupied. Automatic refitting of armor/clothing geometry is still future work; this fallback prevents obvious mesh/armor intersections. `verify-project.py` is a structural check only, not a Forge compile or in-game test.
